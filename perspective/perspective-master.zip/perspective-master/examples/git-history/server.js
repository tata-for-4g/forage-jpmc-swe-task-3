/******************************************************************************
 *
 * Copyright (c) 2017, the Perspective Authors.
 *
 * This file is part of the Perspective library, distributed under the terms of
 * the Apache License 2.0.  The full license can be found in the LICENSE file.
 *
 */

const { WebSocketServer, table } = require("@finos/perspective");
const exec = require("child_process").exec;

function execute(command, callback) {
    exec(command, { maxBuffer: 1024 * 5000 }, function (error, stdout) {
        callback(stdout);
    });
}

const server = new WebSocketServer({ assets: [__dirname] });

const schema = {
    Hash: "string",
    Name: "string",
    Date: "integer",
    Message: "string",
    Email: "string",
};

execute(
    `git log --date=unix --pretty=format:'^^^^%h^^^^,^^^^%an^^^^,%ad,^^^^%s^^^^,^^^^%ae^^^^' | sed 's/"//g' | sed 's/\\^^^^/"/g'`,
    async (log) => {
        const tbl = await table(schema);
        await tbl.update("Hash,Name,Date,Message,Email\n" + log);
        server.host_table("data_source_one", tbl);
    }
);
