/******************************************************************************
 *
 * Copyright (c) 2017, the Perspective Authors.
 *
 * This file is part of the Perspective library, distributed under the terms of
 * the Apache License 2.0.  The full license can be found in the LICENSE file.
 *
 */

import { WebSocketManager, perspective_assets } from "@finos/perspective";
import path from "path";
import express from "express";
import expressWs from "express-ws";
import { securities } from "../../datasources/index.js";

import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

console.log(path.resolve(__dirname, "../dist"));

const app = expressWs(express()).app;

const manager = new WebSocketManager();
securities().then((table) => manager.host_table("remote_table", table));

app.ws("/subscribe", (ws) => manager.add_connection(ws));
app.use("/", perspective_assets([path.resolve(__dirname, "../dist")], true));

const server = app.listen(8080, () =>
    console.log(`Listening on port ${server.address().port}`)
);
