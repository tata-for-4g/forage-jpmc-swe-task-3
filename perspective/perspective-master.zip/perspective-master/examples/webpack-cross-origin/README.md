# Webpack Example

An example of consuming perspective through webpack, via `webpack-dev-server`, 
hosted cross origin.