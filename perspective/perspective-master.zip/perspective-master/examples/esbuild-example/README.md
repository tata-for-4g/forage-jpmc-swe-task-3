# `esbuild` Example

Simple `esbuild` example using `perspective-viewer` and plugins.
