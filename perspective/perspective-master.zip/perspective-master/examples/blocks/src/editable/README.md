A simple example of [Perspective](https://github.com/finos/perspective) with superstore
data, and editability enabled (not default but easy to toggle at runtime). This
example has no server component, and the edits occur only within the browser session;
refreshing the page will forget any edits and revert to the original dataset.
