Demo of [Perspective](https://github.com/finos/perspective).

This example of a `<perspective-workspace>` dashboard is generated from one
[Apache Arrow]() source dataset, converted originally from this [XLS from a
Tableau presentation](https://community.tableau.com/docs/DOC-1236).
This layout is just an example; you can explore your own visualizations in the Perspective
configuration menu, accessed by clicking the dropdown arrow in each pane's upper
left, or advanced options in the pane's right-click context menu.
