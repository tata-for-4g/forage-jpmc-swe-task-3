# `perspective-workspace` client-server editing example

For this example to work, you'll need a `perspective-python` server running
over a websocket at an accessible URL. This example is preconfigured to use
`server.py` in the `src` folder.

Make sure you have `perspective-python` built locally, and then run
`yarn start:server` and `yarn start:client` in separate shells.
