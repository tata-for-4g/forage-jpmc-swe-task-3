# Webpack Example

Simple webpack example using `perspective-viewer` and plugins.