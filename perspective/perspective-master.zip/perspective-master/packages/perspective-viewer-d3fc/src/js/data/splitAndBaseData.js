/******************************************************************************
 *
 * Copyright (c) 2017, the Perspective Authors.
 *
 * This file is part of the Perspective library, distributed under the terms of
 * the Apache License 2.0.  The full license can be found in the LICENSE file.
 *
 */
import { labelFunction } from "../axis/axisLabel";

export function splitAndBaseData(settings, data) {
    const labelfn = labelFunction(settings);

    return data.map((col, i) => {
        const baseValues = {};

        return Object.keys(col)
            .filter((key) => key !== "__ROW_PATH__")
            .map((key) => {
                // Keys are of the form "split1|split2|aggregate"
                const labels = key.split("|");
                // label="aggregate"
                const label = labels[labels.length - 1];
                const baseValue = baseValues[label] || 0;
                const value = baseValue + col[key];
                baseValues[label] = value;

                return {
                    key,
                    crossValue: labelfn(col, i),
                    mainValue: value,
                    baseValue: baseValue,
                    row: col,
                };
            });
    });
}
