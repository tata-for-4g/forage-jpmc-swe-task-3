/******************************************************************************
 *
 * Copyright (c) 2017, the Perspective Authors.
 *
 * This file is part of the Perspective library, distributed under the terms of
 * the Apache License 2.0.  The full license can be found in the LICENSE file.
 *
 */

import { groupFromKey } from "../series/seriesKey";

export function xySplitData(settings, data) {
    const n_cols = settings.mainValues.length;

    return data.map((col) => {
        const cols = Object.keys(col).filter((key) => key !== "__ROW_PATH__");
        const row = new Array(cols.length / n_cols);
        for (let i = 0; i < cols.length / n_cols; i++) {
            row[i] = {
                key: groupFromKey(cols[i * n_cols]),
                crossValue: col[cols[i * n_cols]],
                mainValue: col[cols[i * n_cols + 1]],
                row: col,
            };
        }
        return row;
    });
}
