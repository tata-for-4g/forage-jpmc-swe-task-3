/******************************************************************************
 *
 * Copyright (c) 2017, the Perspective Authors.
 *
 * This file is part of the Perspective library, distributed under the terms of
 * the Apache License 2.0.  The full license can be found in the LICENSE file.
 *
 */

import barChart from "./bar";
import columnChart from "./column";
import lineChart from "./line";
import xyLine from "./xy-line";
import areaChart from "./area";
import yScatter from "./y-scatter";
import xyScatter from "./xy-scatter";
import heatmap from "./heatmap";
import ohlc from "./ohlc";
import candlestick from "./candlestick";
import sunburst from "./sunburst";
import treemap from "./treemap";

const chartClasses = [
    barChart,
    columnChart,
    lineChart,
    xyLine,
    areaChart,
    yScatter,
    xyScatter,
    ohlc,
    candlestick,
    treemap,
    sunburst,
    heatmap,
];

export default chartClasses;
