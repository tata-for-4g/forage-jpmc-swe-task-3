/******************************************************************************
 *
 * Copyright (c) 2017, the Perspective Authors.
 *
 * This file is part of the Perspective library, distributed under the terms of
 * the Apache License 2.0.  The full license can be found in the LICENSE file.
 *
 */
import { rebindAll } from "d3fc";
import { axisType } from "./axisType";
import { labelFunction as noLabel } from "./noAxis";
import { labelFunction as timeLabel } from "./timeAxis";
import { labelFunction as linearLabel } from "./linearAxis";
import { labelFunction as ordinalLabel } from "./ordinalAxis";

const labelFunctions = {
    none: noLabel,
    ordinal: ordinalLabel,
    time: timeLabel,
    linear: linearLabel,
};

export const labelFunction = (settings) => {
    const base = axisType(settings);
    let valueName = "__ROW_PATH__";

    const label = (d, i) => {
        return labelFunctions[base()](valueName)(d, i);
    };

    rebindAll(label, base);

    label.valueName = (...args) => {
        if (!args.length) {
            return valueName;
        }
        valueName = args[0];
        return label;
    };

    return label;
};
