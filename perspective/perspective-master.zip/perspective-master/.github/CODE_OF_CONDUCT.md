# Code of Conduct for Perspective

Please see the [Community Code of Conduct](https://www.finos.org/code-of-conduct).
