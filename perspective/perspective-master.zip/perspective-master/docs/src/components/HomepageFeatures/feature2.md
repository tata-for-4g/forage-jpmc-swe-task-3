A framework-agnostic User Interface packaged as a
[Custom Element](https://developer.mozilla.org/en-US/docs/Web/Web_Components/Using_custom_elements),
powered either in-browser via WebAssembly or virtually via
WebSocket server (Python/Node).
