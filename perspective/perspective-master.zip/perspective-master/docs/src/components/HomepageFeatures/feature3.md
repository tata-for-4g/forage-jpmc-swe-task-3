A [JupyterLab](https://jupyter.org/) widget and Python client library, for
interactive data analysis in a notebook, as well as _scalable_ production
[Voila](https://github.com/voila-dashboards/voila) applications.
