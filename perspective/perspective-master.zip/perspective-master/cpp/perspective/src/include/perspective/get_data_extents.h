/******************************************************************************
 *
 * Copyright (c) 2017, the Perspective Authors.
 *
 * This file is part of the Perspective library, distributed under the terms of
 * the Apache License 2.0.  The full license can be found in the LICENSE file.
 *
 */

#pragma once

#include <perspective/first.h>
#include <perspective/raw_types.h>
#include <algorithm>

namespace perspective {

struct t_get_data_extents {
    t_index m_srow;
    t_index m_erow;
    t_index m_scol;
    t_index m_ecol;
};

t_get_data_extents sanitize_get_data_extents(t_index nrows, t_index ncols,
    t_index start_row, t_index end_row, t_index start_col, t_index end_col);
} // namespace perspective
