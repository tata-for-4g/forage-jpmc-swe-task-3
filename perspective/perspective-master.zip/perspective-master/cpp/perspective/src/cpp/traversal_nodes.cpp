/******************************************************************************
 *
 * Copyright (c) 2017, the Perspective Authors.
 *
 * This file is part of the Perspective library, distributed under the terms of
 * the Apache License 2.0.  The full license can be found in the LICENSE file.
 *
 */

#include <perspective/first.h>
#include <perspective/traversal_nodes.h>

namespace perspective {

void
fill_travnode(t_tvnode* node, bool expanded, t_uindex depth, t_uindex rel_pidx,
    t_uindex ndesc, t_uindex tnid) {
    node->m_expanded = expanded;
    node->m_depth = depth;
    node->m_rel_pidx = rel_pidx;
    node->m_ndesc = ndesc;
    node->m_tnid = tnid;
    node->m_nchild = 0;
}
}; // namespace perspective
